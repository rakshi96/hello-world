# maven-project

Simple Maven Project
simple devops project for build

Pol Schedule
*/2 * * * *
